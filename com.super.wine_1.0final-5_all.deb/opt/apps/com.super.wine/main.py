#!/usr/bin/python3
from glob import glob
import sys,os,ttkthemes,platform,webbrowser
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
path=sys.path[0]
iconpath=f'{path}/icon.png'
wine=0
wineprefix='$HOME/.wine'
winearch=0
window=tk.Tk()

#判断缩放比例
height=window.winfo_screenheight()
width=window.winfo_screenwidth()
if height > width:
    scrshort=width
else:
    scrshort=height
abc=1.0
print(scrshort)
for i in [800,1080,1280,1600,2000,2160,2400,2560,2880,3120,3400,3980,4320]:
    if scrshort>i:
        abc+=0.25
print(abc)
window.title('超级Wine-1.0Final')
window.minsize(int(650*abc),int(325*abc))
window.maxsize(0,0)
window.iconphoto(False,tk.PhotoImage(file=iconpath))
style = ttkthemes.ThemedStyle(window)
style.set_theme("breeze")

# 创建列表选项

os.system(f'chmod 777 {__file__}')
choosewinelabel=tk.Label(window,text='请选择你需要使用的Wine',font=('Arial',10))
choosewinelabel.place(x=int(25*abc),y=int(15*abc))
winelist = [('Wine','wine'),
        ('Wine64','wine64'),
        ('Wine-stable','wine-stable'),
        ('deepin-wine','deepin-wine'),
        ('deepin-wine5','deepin-wine5'),
        ('deepin-wine5-stable','deepin-wine5-stable'),
        ('deepin-wine6-stable','deepin-wine6-stable')]
# IntVar() 用于处理整数类型的变量
choosewine = tk.StringVar()
tmp=int(60*abc)

# 设置好wine版本
def choosewinefine():
    global wine
    wine=choosewine.get()
for name, num in winelist:
    ttk.Radiobutton(window,text = name, variable = choosewine,value =num, command=choosewinefine).place(x=int(25*abc),y=tmp,width=int(150*abc),height=int(30*abc))
    tmp+=int(30*abc)

#Wine架构
choosewinearch=tk.StringVar()
def choosewinearchfine():
    global winearch
    winearch=choosewinearch.get()
ttk.Label(window,text='[可不选] 选择Wine容器架构, 创建32位容器后不能运行为64位').place(x=int(240*abc),y=int(15*abc))
ttk.Radiobutton(window,text='32位(win32)',variable=choosewinearch,value='win32',command=choosewinearchfine).place(x=int(240*abc),y=int(40*abc))
ttk.Radiobutton(window,text='64位(win64)',variable=choosewinearch,value='win64',command=choosewinearchfine).place(x=int(330*abc),y=int(40*abc))
#Wine容器路径
wineprefixlabel=ttk.Label(window,text='请选择或输入Wine容器路径,不选择默认值为$HOME/.wine',font=('Arial',10))
wineprefixlabel.place(x=int(240*abc),y=int(75*abc))
wineprefixbox=ttk.Combobox(window,font=('Arial',10))
wineprefixbox.place(x=int(240*abc),y=int(110*abc),width=int(325*abc),height=int(25*abc))
def choosewineprefix():
    global wineprefix
    wineprefix=filedialog.askdirectory()
    wineprefixbox.insert(0, wineprefix)
ttk.Button(window,text='选择',command=choosewineprefix).place(x=int(565*abc),y=int(110*abc),width=int(75*abc),height=int(25*abc))

#EXE程序路径
ttk.Label(window,text='请选择或输入EXE文件路径,桌面在$HOME/Desktop',font=('Arial',10)).place(x=int(240*abc),y=int(165*abc))
exepathbox=ttk.Combobox(window,font=('Arial',10))
exepathbox.place(x=int(240*abc),y=int(200*abc),width=int(325*abc),height=int(25*abc))
def chooseexepath():
    global exepath
    exepath=filedialog.askopenfilename()
    exepathbox.insert(0, exepath)
ttk.Button(window,text='选择',command=chooseexepath).place(x=int(565*abc),y=int(200*abc),width=int(75*abc),height=int(25*abc))


# 关闭窗口
def close_window():
    window.destroy()
ttk.Button(window,text='退出' ,command=close_window).place(x=int(505*abc),y=int(260*abc),width=int(50*abc),height=int(30*abc))

#运行程序
def execprogram():
    if wine != 0:
        wineprefix=wineprefixbox.get()
        exepath=exepathbox.get()
        if winearch:
            os.system(f'WINEPREFIX={wineprefix} WINEARCH={winearch} {wine} {exepath}')
        else:
            os.system(f'WINEPREFIX={wineprefix} {wine} {exepath}')
    else:
        messagebox.showerror(title='错误',message='未选择Wine或EXE文件路径, 无法运行')
ttk.Button(window,text='运行',command=execprogram).place(x=int(565*abc),y=int(260*abc),width=int(75*abc),height=int(30*abc))

#帮助
def winerunnerhelp():
    webbrowser.open('https://gitee.com/x543054305/super-wine/wikis/%E5%85%B3%E4%BA%8E%E8%B6%85%E7%BA%A7Wine1.0-final')
ttk.Button(window,text='帮助', command=winerunnerhelp).place(x=int(440*abc),y=int(260*abc),width=int(60*abc),height=int(30*abc))

# 如果是Linux系统就显示窗口，否则报错
if platform.system() == 'Linux':
    window.mainloop()
else:
    messagebox.showerror(title='错误',message='抱歉,本程序仅支持在Linux下运行 \n 下载地址deepin.org')
